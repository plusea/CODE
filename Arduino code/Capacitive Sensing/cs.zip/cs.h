#ifndef TOUCH
#define TOUCH

int boogieball (int);

#endif	/* TOUCH */
