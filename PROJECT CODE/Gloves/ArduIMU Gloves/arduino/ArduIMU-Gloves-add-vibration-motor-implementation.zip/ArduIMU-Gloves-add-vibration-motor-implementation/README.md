ArduIMU-Gloves
==============

http://theglovesproject.com/category/diy/

Comment out line "#define BINARY_PACKETS" in "Send.c" to enable ASCII packet mode.
