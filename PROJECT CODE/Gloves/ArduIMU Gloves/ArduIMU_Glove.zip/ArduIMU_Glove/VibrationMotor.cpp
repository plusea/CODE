/*
    VinbrationMotor.cpp
    Author: Seb Madgwick
*/

//------------------------------------------------------------------------------
// Includes

#include <Arduino.h>
#include "VibrationMotor.h"

//------------------------------------------------------------------------------
// Definitions

//------------------------------------------------------------------------------
// Variables

//------------------------------------------------------------------------------
// Methods

void VibrationMotor::init() {
}

void VibrationMotor::doTasks() {
}

void VibrationMotor::pulse(const char num) {
}

//------------------------------------------------------------------------------
// End of file
